from django.http import JsonResponse
from django.shortcuts import redirect, render, HttpResponse
from core.constants.doctor_constants import (
    AppointmentStatus,
    AppointmentType,
    DoctorSpeciality,
)
from doctor.models import Appointment
from django.contrib.auth.decorators import login_required

from user.models import Doctor


@login_required
def index(request):
    speciality = request.GET.get("current_speciality") or DoctorSpeciality.NEUROLOGIST
    context = {
        "title": "Doctors",
        "specialities": DoctorSpeciality.choices,
        "doctors": Doctor.objects.filter(speciality=speciality),
        "current_speciality": speciality,
    }
    return render(request, "doctors.html", context=context)


@login_required
def doctor_appointments(request):
    context = {
        "title": "Booked Appointments",
        "appointments": Appointment.objects.filter(doctor=request.user).all()
    }
    return render(request, "doctor-appointments.html", context=context)


def book_appointment(request):
    if request.method == "POST":
        data = request.POST
        _ = Appointment.objects.create(
            patient=request.user,
            doctor_id=data["selectedDoctorId"],
            appointment_date=data["appointmentDate"],
            description=data["appointmentDescription"],
            type=AppointmentType.ONLINE
            if data.get("online") == "on"
            else AppointmentType.INCLINIC,
        )
        return JsonResponse({
            "message": "Appointment Booked Successfully",
            "url": redirect('appointments').url
        })
    return HttpResponse("Failed to book appointment. Please try again later.", status=400)


def make_payment(request):
    if request.method == "POST":
        data = request.POST
        print(data)
        if data.get("product_identity") == "1234567890":
            appointment = Appointment.objects.filter(id=data.get("appointment_id"))
            if appointment.exists():
                instance = appointment.first()
                instance.status = AppointmentStatus.BOOKED
                instance.save()
                return HttpResponse("Payment Success.")
    return HttpResponse("Payment failed.", status=400)


def cancel_booking(request):
    if request.method == "POST":
        data = request.POST
        appointment = Appointment.objects.filter(id=data.get("appointment_id"))
        if appointment.exists():
            instance = appointment.first()
            instance.status = AppointmentStatus.CANCELLED
            instance.save()
            return HttpResponse("Appointment Cancelled.")
    return HttpResponse("Action failed.", status=400)


def delete_booking(request):
    if request.method == "POST":
        data = request.POST
        appointment = Appointment.objects.filter(id=data.get("appointment_id"))
        if appointment.exists():
            instance = appointment.first()
            instance.delete()
            return HttpResponse("Appointment Deleted.")
    return HttpResponse("Action failed.", status=400)


def create_meeting(request):
    if request.method == "POST":
        data = request.POST
        appointment = Appointment.objects.filter(id=data.get("appointment_id"))
        if appointment.exists():
            instance = appointment.first()
            instance.meeting_link = data.get("link")
            instance.save()
            return HttpResponse("Meeting created.")
    return HttpResponse("Action failed.", status=400)
