from django.contrib import admin

from doctor.models import Appointment

admin.site.register(Appointment)