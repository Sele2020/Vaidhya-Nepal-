from django.urls import path

from doctor.views import (
    book_appointment,
    cancel_booking,
    create_meeting,
    doctor_appointments,
    index,
    make_payment,
    delete_booking,
)

urlpatterns = [
    path("", index, name="doctors-index"),
    path("book-appointment/", book_appointment, name="book-appointment"),
    path("make-payment/", make_payment, name="make-payment"),
    path("cancel-booking/", cancel_booking, name="cancel-booking"),
    path("delete-booking/", delete_booking, name="delete-booking"),
    path("doctor-appointments/", doctor_appointments, name="doctor-appointments"),
    path("create-meeting", create_meeting, name="create-meeting")
]
