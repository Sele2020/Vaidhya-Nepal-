from django.db import models
from core.constants.doctor_constants import AppointmentStatus, AppointmentType

from user.models import User
from django.utils import timezone

class Appointment(models.Model):
    patient = models.ForeignKey(User, on_delete=models.CASCADE, null=False, related_name="appointment_patient")
    doctor = models.ForeignKey(User, on_delete=models.CASCADE, null=False, related_name="appointment_doctor")
    appointment_date = models.DateTimeField(null=False, default=timezone.now)
    description = models.TextField(null=False)
    status = models.CharField(max_length=20, choices=AppointmentStatus.choices, default=AppointmentStatus.PENDING)
    type = models.CharField(max_length=20, choices=AppointmentType.choices, default=AppointmentType.ONLINE)
    meeting_link = models.TextField(null=True)
    class Meta:
        db_table = 'appointments'
        app_label = "doctor"
        ordering = ["-id"]
    
    def __str__(self) -> str:
        return f"{self.patient} - {self.doctor} -> {self.status}"
