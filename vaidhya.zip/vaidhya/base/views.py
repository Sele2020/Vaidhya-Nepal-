import uuid
from django.shortcuts import redirect, render
from django.contrib.auth import login, logout, authenticate
from django.urls import reverse
from doctor.models import Appointment
from user.models import Doctor, Token, User
from django.contrib.auth.decorators import login_required

from django.conf import settings
from django.core.mail import send_mail


def login_user(request):
    context = {"title": "Login"}
    if request.method == "POST":
        user = authenticate(
            request, email=request.POST["email"], password=request.POST["password"]
        )
        if user:
            login(request, user)
            if user.is_patient():
                return redirect("base-index")
            elif not user.is_patient():
                return redirect("doctor-appointments")
        else:
            context["message"] = "Incorrect Credentials"
    return render(request, "auth/login.html", context=context)


def signup_user(request):
    error = None
    if request.method == "POST":
        full_name = request.POST["full_name"]
        mobile = request.POST["mobile"]
        email = request.POST["email"]
        password = request.POST["password"]

        if User.objects.filter(email=email).exists():
            error = "Email already registered."

        if User.objects.filter(mobile_no=mobile).exists():
            error = "Mobile already registered."

        if not error:
            user = User.objects.create(full_name=full_name, mobile_no=mobile, email=email)
            user.set_password(password)
            user.save()
            return redirect("user-login")

    context = {"title": "Sign Up", "error": error}
    return render(request, "auth/signup.html", context=context)


def forgot_password(request):
    context = {
        "title": "Forgot Password"
    }
    if request.method == "POST":
        data = request.POST
        if data.get("email"):
            user = User.objects.filter(email=data.get("email"))
            if user.exists():
                token = str(uuid.uuid4())
                Token.objects.create(token=token, user=user[0])

                url = request.build_absolute_uri(reverse('forgot-password-confirm', args=[token]))
                print(url)

                subject = 'Reset Password - Vaidhya'
                plain_message = f'Hi {user[0].full_name}, please follow the below link to reset your password.\nf{url}'
                html_message = f'Hi {user[0].full_name}, please follow this <a href="{url}">link</a> to reset your password.'
                email_from = settings.EMAIL_HOST_USER
                recipient_list = [user[0].email, ]
                send_mail( subject, plain_message, email_from, recipient_list, html_message=html_message )
            context["message"] = "Reset password link has been sent to your registered email address."
    return render(request, "auth/forgot-password.html", context=context)


def forgot_password_confirm(request, token):
    context = {
        "title": "Set New Password"
    }
    if request.method == "POST":
        data = request.POST
        print(data)
        if token and data.get("password"):
            token = Token.objects.filter(token=token)
            if token.exists():
                user = token[0].user
                user.set_password(data.get("password"))
                user.save()
        return redirect('user-login')
    return render(request, "auth/forgot-password-confirm.html", context=context)

def logout_user(request):
    logout(request)
    return redirect("user-login")


def index(request):
    doctors = Doctor.objects.all()[:3]
    context = {"title": "Home", "doctors": doctors}
    return render(request, "index.html", context=context)


def about_us(request):
    context = {
        "title": "About",
    }
    return render(request, "about-us.html", context=context)


@login_required
def appointments(request):
    context = {
        "title": "Appointments",
        "appointments": Appointment.objects.filter(patient=request.user).all(),
    }
    return render(request, "appointments.html", context=context)
