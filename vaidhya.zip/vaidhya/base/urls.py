from django.urls import path

from base.views import about_us, appointments, forgot_password, forgot_password_confirm, index, login_user, logout_user, signup_user

urlpatterns = [
    path("", index, name="base-index"),
    path("login/", login_user, name="user-login"),
    path("signup/", signup_user, name="user-signup"),
    path("forgot-password/", forgot_password, name="forgot-password"),
    path("forgot-password/confirm/<token>", forgot_password_confirm, name="forgot-password-confirm"),
    path("logout/", logout_user, name="user-logout"),
    path("about-us/", about_us, name="about-us"),
    path('appointments/', appointments, name='appointments')
]
