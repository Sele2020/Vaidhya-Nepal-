from django.db import models

class UserRole(models.TextChoices):
    DOCTOR = "DOCTOR"
    PATIENT = "PATIENT"
