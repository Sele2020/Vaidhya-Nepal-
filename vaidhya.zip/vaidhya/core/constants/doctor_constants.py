from django.db import models

class DoctorSpeciality(models.TextChoices):
    NEUROLOGIST = "Neurologist"
    CARDIOLOGIST = "Cardiologist"
    SURGEON = "Surgeon"
    PEDIATRICS = "Pediatrics"
    PSYCHIATRICS = "Psychiatrics"
    PHYSICIAN = "Physician"
    GYNAECOLOGIST = "Gynaecologist"


class AppointmentStatus(models.TextChoices):
    PENDING = "Pending"
    BOOKED = "Booked"
    CANCELLED = "Cancelled"


class AppointmentType(models.TextChoices):
    ONLINE = "ONLINE"
    INCLINIC = "INCLINIC"
