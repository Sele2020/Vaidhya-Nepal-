from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from user.models import User, Patient, Doctor
from django.contrib.auth.models import Group


class CustomUserAdmin(UserAdmin):
    model = User
    list_display = (
        "id",
        "mobile_no",
        "email",
        "is_active",
    )
    list_filter = ("is_active",)
    readonly_fields = ("date_joined",)
    fieldsets = (
        (
            None,
            {
                "fields": (
                    "mobile_no",
                    "email",
                    "password",
                    "full_name",
                    "date_of_birth",
                    "address",
                    "gender",
                    "image",
                )
            },
        ),
        ("Permissions", {"fields": ("role", "is_admin", "is_active")}),
        ("Others", {"fields": ("date_joined",)}),
    )
    filter_horizontal = []
    add_fieldsets = (
        (
            None,
            {
                "classes": ("wide",),
                "fields": (
                    "full_name",
                    "email",
                    "mobile_no",
                    "date_of_birth",
                    "address",
                    "role",
                    "password1",
                    "password2",
                    "is_admin",
                    "is_active",
                ),
            },
        ),
    )
    search_fields = ("mobile_no",)
    ordering = ("mobile_no",)


admin.site.register(User, CustomUserAdmin)
admin.site.register(Doctor)
admin.site.register(Patient)
