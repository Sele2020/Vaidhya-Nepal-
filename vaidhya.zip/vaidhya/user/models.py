from django.contrib.auth.models import AbstractBaseUser
from django.db import models

from core.constants.doctor_constants import DoctorSpeciality
from core.constants.user_constants import UserRole
from core.utils import get_profile_picture_file_path, resize
from user.managers import CustomUserManager
from PIL import Image
from django_resized import ResizedImageField

class User(AbstractBaseUser):
    full_name = models.CharField(max_length=50, null=False)
    email = models.EmailField(unique=True, null=False)
    mobile_no = models.CharField(max_length=10, null=False, unique=True)
    address = models.CharField(max_length=255, null=False)
    gender = models.CharField(max_length=20, null=False)
    date_of_birth = models.DateField(null=True)
    role = models.CharField(
        max_length=7, choices=UserRole.choices, null=False, default=UserRole.PATIENT
    )
    image = models.ImageField(
        upload_to=get_profile_picture_file_path, default="profile_pictures/default.jpg"
    )
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)
    date_joined = models.DateTimeField(auto_now_add=True, null=True)
    last_login = models.DateTimeField(auto_now_add=True, null=True)

    USERNAME_FIELD = "email"

    objects = CustomUserManager()
    REQUIRED_FIELDS = ("mobile_no",)

    class Meta:
        db_table = 'users'
        app_label = "user"
        ordering = ["-id"]

    @property
    def is_staff(self):
        return self.is_admin

    def has_perm(self, perm):
        return self.is_admin

    def has_module_perms(self, perm):
        return self.is_admin

    def __str__(self):
        return self.full_name

    def is_patient(self):
        return Patient.objects.filter(user=self).first()

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)  # saving image first

        img = resize(self.image.path, 260, 240) # Open image using self
        img.save(self.image.path)  # saving image at the same path

class Doctor(models.Model):
    user = models.OneToOneField(
        User, on_delete=models.CASCADE, null=False, related_name="doctor"
    )
    speciality = models.CharField(max_length=20, choices=DoctorSpeciality.choices, null=False)

    class Meta:
        db_table = 'doctors'
        app_label = "user"
        ordering = ["-id"]

    def __str__(self) -> str:
        return f"{self.speciality} - {self.user.full_name}"


class Patient(models.Model):
    user = models.OneToOneField(
        User, on_delete=models.CASCADE, null=False, related_name="patient"
    )

    class Meta:
        db_table = 'patients'
        app_label = "user"
        ordering = ["-id"]

    def __str__(self) -> str:
        return f"Patient - {self.user.full_name}"

class Token(models.Model):
    token = models.CharField(max_length=100)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
